const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const path = require('path');

// إعداد المسار إلى ملفات الواجهة الأمامية
app.use(express.static(path.join(__dirname, 'public')));

// عند دخول مستخدم جديد
io.on('connection', (socket) => {
    console.log('🔌 مستخدم جديد اتصل');

    // استقبال رسالة من المستخدم
    socket.on('chat message', (msg) => {
        io.emit('chat message', msg); // إرسالها لكل المستخدمين
    });

    socket.on('disconnect', () => {
        console.log('❌ مستخدم قطع الاتصال');
    });
});

// تشغيل السيرفر
const PORT = 3000;
http.listen(PORT, () => {
    console.log(`🚀 السيرفر يعمل على http://localhost:${PORT}`);
});